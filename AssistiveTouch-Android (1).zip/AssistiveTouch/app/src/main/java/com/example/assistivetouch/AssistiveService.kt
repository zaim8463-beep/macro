package com.example.assistivetouch

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.*
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.*
import java.util.Locale
import kotlin.math.hypot

class ButtonView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        p.color = 0xE61C1C1E.toInt(); cv.drawRoundRect(0f, 0f, w, w, w * .28f, w * .28f, p)
        p.color = 0xFF8E8E93.toInt(); cv.drawCircle(w / 2, w / 2, w * .30f, p)
        p.color = 0xFFD1D1D6.toInt(); cv.drawCircle(w / 2, w / 2, w * .20f, p)
    }
}

class AssistiveService : AccessibilityService() {
    companion object { var instance: AssistiveService? = null }

    lateinit var wm: WindowManager
    private val h = Handler(Looper.getMainLooper())
    private var button: View? = null
    private var menu: View? = null
    private var fingers: View? = null
    private val stack = ArrayList<String>()
    private var torchOn = false
    private var tts: TextToSpeech? = null
    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, k ->
        if (k == "btn" || k == "size" || k == "opacity") h.post { rebuildButton() }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun opacity() = Prefs.sp(this).getInt("opacity", 60) / 100f

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(listener)
        rebuildButton()
    }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() {
        instance = null
        Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(listener)
        closeMenu(); stopFingers(); button?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        tts?.shutdown(); super.onDestroy()
    }

    // ---------- الزر العائم ----------
    private fun rebuildButton() {
        button?.let { try { wm.removeView(it) } catch (_: Exception) {} }; button = null
        val sp = Prefs.sp(this)
        if (!sp.getBoolean("btn", true)) return
        val size = dp(sp.getInt("size", 56)); val dm = resources.displayMetrics
        val v = ButtonView(this)
        val p = WindowManager.LayoutParams(size, size, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.START
        p.x = sp.getInt("x", dm.widthPixels - size); p.y = sp.getInt("y", dm.heightPixels / 2)
        v.alpha = opacity(); attachTouch(v, p)
        wm.addView(v, p); button = v
    }

    private fun attachTouch(v: View, p: WindowManager.LayoutParams) {
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false; var longFired = false
        var pending: Runnable? = null
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        val longRun = Runnable {
            longFired = true; v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            run(Prefs.act(this, "act_long"))
        }
        v.setOnTouchListener { _, e ->
            val sp = Prefs.sp(this)
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    dx = e.rawX; dy = e.rawY; sx = p.x; sy = p.y; moved = false; longFired = false
                    v.alpha = 1f; h.postDelayed(longRun, sp.getInt("lp", 500).toLong())
                }
                MotionEvent.ACTION_MOVE -> {
                    val mx = e.rawX - dx; val my = e.rawY - dy
                    if (!moved && hypot(mx, my) > slop) { moved = true; h.removeCallbacks(longRun) }
                    if (moved) { p.x = (sx + mx).toInt(); p.y = (sy + my).toInt(); wm.updateViewLayout(v, p) }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    h.removeCallbacks(longRun); v.alpha = opacity()
                    if (moved) {
                        val dm = resources.displayMetrics
                        p.x = if (p.x + p.width / 2 < dm.widthPixels / 2) 0 else dm.widthPixels - p.width
                        p.y = p.y.coerceIn(0, dm.heightPixels - p.height)
                        wm.updateViewLayout(v, p)
                        sp.edit().putInt("x", p.x).putInt("y", p.y).apply()
                    } else if (!longFired && e.action == MotionEvent.ACTION_UP) {
                        if (pending != null) {
                            h.removeCallbacks(pending!!); pending = null; run(Prefs.act(this, "act_double"))
                        } else if (Prefs.act(this, "act_double") == "none") {
                            run(Prefs.act(this, "act_single"))
                        } else {
                            pending = Runnable { pending = null; run(Prefs.act(this, "act_single")) }
                            h.postDelayed(pending!!, sp.getInt("dt", 280).toLong())
                        }
                    }
                }
            }
            true
        }
    }

    // ---------- القائمة (نفس هيكل iOS: أعلى مستوى + الجهاز + المزيد + مخصص + إيماءات) ----------
    private fun pageItems(page: String): List<String> = when (page) {
        "top" -> Prefs.slots(this)
        "device" -> listOf("lock", "rotate", "volup", "mute", "voldown", "more")
        "more" -> listOf("gestures", "recents", "screenshot", "speak", "shortcut", "power", "rotlock", "brightup", "brightdown", "torch", "back", "home")
        "gestures" -> listOf("fingers:2", "fingers:3", "fingers:4", "fingers:5")
        "custom" -> Prefs.gestures(this).keys().asSequence().map { "gesture:$it" }.toList() + "newgesture"
        else -> emptyList()
    }

    private fun showMenu() { stack.clear(); stack.add("top"); renderMenu() }

    private fun renderMenu() {
        closeMenuView(); stopFingers()
        val items = pageItems(stack.last()).toMutableList()
        if (stack.size > 1) items.add(0, "__back")
        val root = FrameLayout(this)
        root.setBackgroundColor(0x88000000.toInt())
        root.setOnClickListener { closeMenu() }          // الضغط خارج القائمة يغلقها
        val grid = GridLayout(this).apply {
            columnCount = if (items.size <= 4) 2 else 3; setPadding(dp(12), dp(12), dp(12), dp(12))
            background = GradientDrawable().apply { setColor(0xEE2C2C2E.toInt()); cornerRadius = dp(28).toFloat() }
        }
        items.forEach { id ->
            grid.addView(TextView(this).apply {
                text = (if (id == "__back") "↩ رجوع" else lbl(id)).replaceFirst(" ", "\n")
                setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.CENTER
                setOnClickListener { onItem(id) }
            }, GridLayout.LayoutParams().apply { width = dp(96); height = dp(88) })
        }
        root.addView(grid, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        wm.addView(root, WindowManager.LayoutParams(-1, -1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT))
        menu = root; button?.visibility = View.INVISIBLE
    }

    private fun onItem(id: String) = when {
        id == "__back" -> { stack.removeAt(stack.size - 1); renderMenu() }
        id in PAGES -> { stack.add(id); renderMenu() }
        else -> { closeMenu(); h.postDelayed({ perform(id) }, 350); Unit }
    }

    private fun closeMenuView() { menu?.let { try { wm.removeView(it) } catch (_: Exception) {} }; menu = null }
    private fun closeMenu() { closeMenuView(); button?.visibility = View.VISIBLE }

    // ---------- أصابع متعددة ----------
    private fun startFingers(n: Int) {
        closeMenu(); stopFingers()
        val v = FingersView(this, this, n) { stopFingers() }
        wm.addView(v, WindowManager.LayoutParams(-1, -1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT))
        fingers = v; rebuildButton()                      // يرجّع الزر فوق الطبقة
    }
    private fun stopFingers() { fingers?.let { try { wm.removeView(it) } catch (_: Exception) {} }; fingers = null }

    // ---------- تنفيذ الإجراءات ----------
    fun run(id: String) { when { id == "none" -> {}; id == "menu" -> showMenu(); id in PAGES -> { stack.clear(); stack.add("top"); stack.add(id); renderMenu() } else -> perform(id) } }

    fun perform(id: String) {
        val am = getSystemService(AudioManager::class.java)
        if (id.startsWith("gesture:")) { playGesture(id.removePrefix("gesture:")); return }
        if (id.startsWith("fingers:")) { startFingers(id.removePrefix("fingers:").toInt()); return }
        when (id) {
            "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            "quick" -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
            "screenshot" -> performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
            "lock" -> performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
            "power" -> performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)
            "spotlight" -> if (Build.VERSION.SDK_INT >= 32) performGlobalAction(GLOBAL_ACTION_ACCESSIBILITY_ALL_APPS)
                           else Toast.makeText(this, "يتطلب أندرويد 12L أو أحدث", Toast.LENGTH_SHORT).show()
            "shortcut" -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "newgesture" -> startActivity(Intent(this, RecorderActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "speak" -> speakScreen()
            "volup" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            "voldown" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            "mute" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, AudioManager.FLAG_SHOW_UI)
            "brightup" -> brightness(+30)
            "brightdown" -> brightness(-30)
            "rotlock" -> if (needWrite()) {
                val cur = Settings.System.getInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1)
                Settings.System.putInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1 - cur)
                Toast.makeText(this, if (cur == 1) "تم قفل التدوير" else "تم فتح التدوير", Toast.LENGTH_SHORT).show()
            }
            "rotate" -> if (needWrite()) {
                val cr = contentResolver
                Settings.System.putInt(cr, Settings.System.ACCELEROMETER_ROTATION, 0)
                Settings.System.putInt(cr, Settings.System.USER_ROTATION, (Settings.System.getInt(cr, Settings.System.USER_ROTATION, 0) + 1) % 4)
            }
            "torch" -> try {
                val cm = getSystemService(CameraManager::class.java)
                val cid = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true } ?: return
                torchOn = !torchOn; cm.setTorchMode(cid, torchOn)
            } catch (_: Exception) {}
            "siri" -> try {
                startActivity(Intent(Intent.ACTION_VOICE_COMMAND).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) { Toast.makeText(this, "لا يوجد مساعد صوتي", Toast.LENGTH_SHORT).show() }
        }
    }

    private fun needWrite(): Boolean {
        if (Settings.System.canWrite(this)) return true
        startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return false
    }

    private fun brightness(d: Int) {
        if (!needWrite()) return
        val cr = contentResolver
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        val n = (Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128) + d).coerceIn(1, 255)
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, n)
        Toast.makeText(this, "السطوع ${n * 100 / 255}%", Toast.LENGTH_SHORT).show()
    }

    // ---------- Speak Screen: يقرأ نصوص الشاشة الحالية ----------
    private fun speakScreen() {
        if (tts?.isSpeaking == true) { tts?.stop(); return }
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            if (n.isVisibleToUser) (n.text ?: n.contentDescription)?.let { sb.append(it).append(". ") }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(rootInActiveWindow)
        val text = sb.toString().ifBlank { return }
        tts?.shutdown()
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) { tts?.language = Locale.getDefault(); tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "s") }
        }
    }

    // ---------- تشغيل الإيماءة المسجّلة ----------
    private fun playGesture(name: String) {
        val arr = Prefs.gestures(this).optJSONArray(name) ?: return
        val dm = resources.displayMetrics
        val b = GestureDescription.Builder()
        for (i in 0 until minOf(arr.length(), GestureDescription.getMaxStrokeCount())) {
            val st = arr.getJSONObject(i); val pts = st.getJSONArray("p")
            val path = Path()
            for (j in 0 until pts.length()) {
                val pt = pts.getJSONArray(j)
                val x = (pt.getDouble(0).toFloat() * dm.widthPixels).coerceIn(0f, dm.widthPixels - 1f)
                val y = (pt.getDouble(1).toFloat() * dm.heightPixels).coerceIn(0f, dm.heightPixels - 1f)
                if (j == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            val t0 = pts.getJSONArray(0).getLong(2); val t1 = pts.getJSONArray(pts.length() - 1).getLong(2)
            b.addStroke(GestureDescription.StrokeDescription(path, st.getLong("s"), maxOf(1L, t1 - t0)))
        }
        dispatchGesture(b.build(), null, null)
    }
}
