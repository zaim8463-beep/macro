package com.example.assistivetouch

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.*
import android.os.Bundle
import android.view.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

class Pad(c: Context) : View(c) {
    class Stroke(val s: Long) { val pts = ArrayList<FloatArray>() }
    val strokes = ArrayList<Stroke>()
    private val active = HashMap<Int, Stroke>()
    private var t0 = -1L
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF00E5FF.toInt(); strokeWidth = 10f; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val hint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x88FFFFFF.toInt(); textSize = 48f; textAlign = Paint.Align.CENTER }

    private fun add(e: MotionEvent, i: Int, s: Stroke) =
        s.pts.add(floatArrayOf(e.getX(i) / width, e.getY(i) / height, (e.eventTime - t0).toFloat()))

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                if (t0 < 0) t0 = e.eventTime
                val i = e.actionIndex
                val s = Stroke(e.eventTime - t0); add(e, i, s)
                strokes += s; active[e.getPointerId(i)] = s
            }
            MotionEvent.ACTION_MOVE -> for (i in 0 until e.pointerCount) active[e.getPointerId(i)]?.let { add(e, i, it) }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val i = e.actionIndex
                active.remove(e.getPointerId(i))?.let { add(e, i, it) }
            }
            MotionEvent.ACTION_CANCEL -> active.clear()
        }
        invalidate(); return true
    }

    private var playT = -1f
    fun play() {
        if (strokes.isEmpty()) return
        val total = (strokes.maxOf { it.pts.last()[2] } + 300f).coerceAtLeast(600f)
        ValueAnimator.ofFloat(0f, total).apply {
            duration = total.toLong()
            addUpdateListener { playT = it.animatedValue as Float; invalidate() }
            addListener(object : AnimatorListenerAdapter() { override fun onAnimationEnd(a: Animator) { playT = -1f; invalidate() } })
            start()
        }
    }

    fun clear() { strokes.clear(); active.clear(); t0 = -1; invalidate() }

    fun toJson() = JSONArray().apply {
        strokes.take(10).forEach { s ->
            put(JSONObject().put("s", s.s).put("p", JSONArray().apply {
                s.pts.forEach { put(JSONArray().put(it[0].toDouble()).put(it[1].toDouble()).put(it[2].toLong())) }
            }))
        }
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(0xFF101010.toInt())
        if (strokes.isEmpty()) c.drawText("ارسم الإيماءة هنا (يدعم أكثر من إصبع)", width / 2f, height / 2f, hint)
        if (playT >= 0) strokes.forEach { s ->
            if (playT >= s.s) {
                val pt = s.pts.lastOrNull { it[2] <= playT } ?: s.pts[0]
                c.drawCircle(pt[0] * width, pt[1] * height, 30f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCCFFFFFF.toInt() })
            }
        }
        strokes.forEach { s ->
            val p = Path()
            s.pts.forEachIndexed { i, pt -> if (i == 0) p.moveTo(pt[0] * width, pt[1] * height) else p.lineTo(pt[0] * width, pt[1] * height) }
            if (s.pts.size == 1) c.drawCircle(s.pts[0][0] * width, s.pts[0][1] * height, 14f, paint) else c.drawPath(p, paint)
        }
    }
}

@Suppress("DEPRECATION")
class RecorderActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        val pad = Pad(this)
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }.also { bar.addView(it) }
        btn("إلغاء") { finish() }
        btn("مسح") { pad.clear() }
        btn("تشغيل") { pad.play() }
        btn("حفظ") {
            if (pad.strokes.isEmpty()) { Toast.makeText(this, "ارسم إيماءة أولًا", Toast.LENGTH_SHORT).show(); return@btn }
            val et = EditText(this).apply { hint = "اسم الإيماءة" }
            AlertDialog.Builder(this).setTitle("حفظ الإيماءة").setView(et)
                .setPositiveButton("حفظ") { _, _ ->
                    val n = et.text.toString().trim().ifEmpty { "إيماءة ${System.currentTimeMillis() % 10000}" }
                    Prefs.saveGesture(this, n, pad.toJson()); finish()
                }.setNegativeButton("رجوع", null).show()
        }
        val root = FrameLayout(this)
        root.addView(pad, FrameLayout.LayoutParams(-1, -1))
        root.addView(bar, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        setContentView(root)
    }
}
