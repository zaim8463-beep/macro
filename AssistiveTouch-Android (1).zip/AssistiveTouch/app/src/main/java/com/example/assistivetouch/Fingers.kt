package com.example.assistivetouch

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.abs
import kotlin.math.max

/** أصابع افتراضية (2-5) تتحرك معًا — زي Device > More > Gestures في iOS. */
class FingersView(ctx: Context, private val svc: AssistiveService, private val n: Int, private val onClose: () -> Unit) : View(ctx) {
    private val dm = resources.displayMetrics
    private val spacing = 90f * dm.density
    private val slop = 8f * dm.density
    private var bx = dm.widthPixels / 2f
    private var by = dm.heightPixels / 2f
    private var tx = 0f; private var ty = 0f; private var cx = 0f; private var cy = 0f
    private var down = false; private var t0 = 0L
    private val pts = ArrayList<FloatArray>()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x88FFFFFF.toInt() }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF8E8E93.toInt(); style = Paint.Style.STROKE; strokeWidth = 4f * dm.density }
    private val idle = Runnable { onClose() }

    private fun off(k: Int) = (k - (n - 1) / 2f) * spacing
    override fun onAttachedToWindow() { super.onAttachedToWindow(); postDelayed(idle, 4000) }
    override fun onDetachedFromWindow() { removeCallbacks(idle); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        val dx = if (down) cx - tx else 0f; val dy = if (down) cy - ty else 0f
        for (k in 0 until n) { val x = bx + off(k) + dx; val y = by + dy
            c.drawCircle(x, y, 22f * dm.density, fill); c.drawCircle(x, y, 22f * dm.density, ring) }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        removeCallbacks(idle)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { down = true; tx = e.rawX; ty = e.rawY; cx = tx; cy = ty; t0 = e.eventTime; pts.clear(); pts.add(floatArrayOf(0f, 0f, 0f)) }
            MotionEvent.ACTION_MOVE -> { cx = e.rawX; cy = e.rawY; pts.add(floatArrayOf(cx - tx, cy - ty, (e.eventTime - t0).toFloat())) }
            MotionEvent.ACTION_UP -> { cx = e.rawX; cy = e.rawY; pts.add(floatArrayOf(cx - tx, cy - ty, (e.eventTime - t0).toFloat())); down = false; fire() }
            MotionEvent.ACTION_CANCEL -> { down = false; postDelayed(idle, 4000) }
        }
        invalidate(); return true
    }

    private fun touchable(b: Boolean) {
        val p = layoutParams as WindowManager.LayoutParams
        p.flags = if (b) p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv() else p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        try { svc.wm.updateViewLayout(this, p) } catch (_: Exception) {}
    }

    private fun fire() {
        val w = dm.widthPixels - 1f; val h = dm.heightPixels - 1f
        val moved = pts.any { abs(it[0]) > slop || abs(it[1]) > slop }
        val dur = max(50L, pts.last()[2].toLong())
        val g = GestureDescription.Builder()
        for (k in 0 until n) {
            val x0 = (bx + off(k)).coerceIn(0f, w); val y0 = by.coerceIn(0f, h)
            val p = Path(); p.moveTo(x0, y0)
            if (moved) pts.drop(1).forEach { p.lineTo((x0 + it[0]).coerceIn(0f, w), (y0 + it[1]).coerceIn(0f, h)) }
            g.addStroke(GestureDescription.StrokeDescription(p, 0, dur))
        }
        bx = (bx + cx - tx).coerceIn(0f, w); by = (by + cy - ty).coerceIn(0f, h)
        val back = { touchable(true); invalidate(); postDelayed(idle, 4000); Unit }
        touchable(false)
        val ok = svc.dispatchGesture(g.build(), object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { back() }
            override fun onCancelled(d: GestureDescription?) { back() }
        }, null)
        if (!ok) back()
    }
}
