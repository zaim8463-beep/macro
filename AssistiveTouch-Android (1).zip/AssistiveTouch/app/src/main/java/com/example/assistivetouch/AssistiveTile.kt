package com.example.assistivetouch

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** مثل "triple-click" في iOS: بلاطة في الإعدادات السريعة تُظهر/تُخفي الزر العائم. */
class AssistiveTile : TileService() {
    override fun onStartListening() = refresh()
    override fun onClick() {
        val sp = Prefs.sp(this)
        sp.edit().putBoolean("btn", !sp.getBoolean("btn", true)).apply(); refresh()
    }
    private fun refresh() {
        qsTile?.apply { state = if (Prefs.sp(this@AssistiveTile).getBoolean("btn", true)) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE; updateTile() }
    }
}
