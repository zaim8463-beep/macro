package com.example.assistivetouch

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

val ACTIONS = linkedMapOf(
    "none" to "— لا شيء", "menu" to "☰ فتح القائمة",
    "notifications" to "🔔 مركز الإشعارات", "device" to "📱 الجهاز", "siri" to "🎙 Siri / المساعد",
    "custom" to "⭐ مخصص", "home" to "🏠 الشاشة الرئيسية", "quick" to "🎛 مركز التحكم",
    "spotlight" to "🔍 البحث", "recents" to "🗂 متعدد المهام", "back" to "◀ رجوع",
    "lock" to "🔒 قفل الشاشة", "rotate" to "🔄 تدوير الشاشة", "rotlock" to "🔓 قفل التدوير",
    "volup" to "🔊 رفع الصوت", "voldown" to "🔉 خفض الصوت", "mute" to "🔇 كتم",
    "screenshot" to "📸 لقطة شاشة", "power" to "🔁 إعادة التشغيل", "speak" to "🗣 نطق الشاشة",
    "shortcut" to "♿ اختصار الوصول", "brightup" to "🔆 سطوع +", "brightdown" to "🔅 سطوع −",
    "torch" to "🔦 كشاف", "more" to "⋯ المزيد", "gestures" to "👆 متعدد الأصابع",
    "fingers:2" to "👆 2 أصابع", "fingers:3" to "👆 3 أصابع", "fingers:4" to "👆 4 أصابع", "fingers:5" to "👆 5 أصابع",
    "newgesture" to "➕ إيماءة جديدة",
    "pinch" to "🤏 قرص وتدوير", "longpress" to "👇 ضغط مطوّل", "doubletap" to "👆 نقر مزدوج", "holddrag" to "✋ إمساك وسحب",
    "scrollup" to "⬆ تمرير لأعلى", "scrolldown" to "⬇ تمرير لأسفل", "scrollleft" to "⬅ تمرير لليسار", "scrollright" to "➡ تمرير لليمين"
)
val PAGES = setOf("device", "more", "gestures", "custom")
fun lbl(id: String) = ACTIONS[id] ?: if (id.startsWith("gesture:")) "✋ " + id.removePrefix("gesture:") else id

object Prefs {
    const val DEFAULT_SLOTS = "notifications,custom,device,siri,home,quick"   // نفس القائمة الافتراضية في iOS
    private val DEF = mapOf("act_single" to "menu", "act_double" to "none", "act_long" to "none")

    fun sp(c: Context) = c.getSharedPreferences("at", Context.MODE_PRIVATE)
    fun act(c: Context, k: String) = sp(c).getString(k, DEF[k])!!
    fun slots(c: Context) = sp(c).getString("slots", DEFAULT_SLOTS)!!.split(",").filter { it.isNotEmpty() }
    fun setSlots(c: Context, l: List<String>) = sp(c).edit().putString("slots", l.joinToString(",")).apply()

    fun gestures(c: Context) = JSONObject(sp(c).getString("gestures", "{}")!!)
    fun saveGesture(c: Context, name: String, data: JSONArray) =
        sp(c).edit().putString("gestures", gestures(c).put(name, data).toString()).apply()
    fun deleteGesture(c: Context, name: String) =
        sp(c).edit().putString("gestures", gestures(c).apply { remove(name) }.toString()).apply()
}
