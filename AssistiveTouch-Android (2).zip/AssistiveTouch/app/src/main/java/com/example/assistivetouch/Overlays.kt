package com.example.assistivetouch

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.*

fun View.setTouchable(wm: WindowManager, b: Boolean) {
    val p = layoutParams as? WindowManager.LayoutParams ?: return
    p.flags = if (b) p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv() else p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
    try { wm.updateViewLayout(this, p) } catch (_: Exception) {}
}

/** أيقونات القائمة بنفس شكل iOS (أبيض أحادي اللون) */
class IconView(ctx: Context, private val id: String) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        fun x(v: Float) = v * w
        fun st(t: Float) { p.style = Paint.Style.STROKE; p.strokeWidth = t * w }
        fun fl() { p.style = Paint.Style.FILL }
        fun ring(cx: Float, cy: Float, r: Float, t: Float = .06f) { st(t); c.drawCircle(x(cx), x(cy), x(r), p) }
        fun dot(cx: Float, cy: Float, r: Float) { fl(); c.drawCircle(x(cx), x(cy), x(r), p) }
        fun line(a: Float, b: Float, d: Float, e: Float, t: Float = .06f) { st(t); c.drawLine(x(a), x(b), x(d), x(e), p) }
        p.alpha = 255
        when {
            id == "notifications" -> {
                val b = Path(); b.moveTo(x(.22f), x(.70f)); b.quadTo(x(.30f), x(.55f), x(.30f), x(.40f))
                b.cubicTo(x(.30f), x(.15f), x(.70f), x(.15f), x(.70f), x(.40f)); b.quadTo(x(.70f), x(.55f), x(.78f), x(.70f)); b.close()
                fl(); c.drawPath(b, p); dot(.5f, .84f, .07f)
            }
            id == "device" -> { st(.06f); c.drawRoundRect(x(.30f), x(.10f), x(.70f), x(.90f), x(.09f), x(.09f), p); line(.45f, .80f, .55f, .80f) }
            id == "siri" -> listOf(.3f, .6f, .9f, .6f, .3f).forEachIndexed { i, h -> line(.2f + i * .15f, .5f - h * .3f, .2f + i * .15f, .5f + h * .3f, .08f) }
            id == "custom" || id.startsWith("gesture:") -> {
                val s = Path()
                for (i in 0 until 10) {
                    val r = if (i % 2 == 0) .42f else .18f; val a = -PI / 2 + i * PI / 5
                    val px = x(.5f + r * cos(a).toFloat()); val py = x(.5f + r * sin(a).toFloat())
                    if (i == 0) s.moveTo(px, py) else s.lineTo(px, py)
                }
                s.close(); fl(); c.drawPath(s, p)
            }
            id == "home" -> { ring(.5f, .5f, .40f, .06f); dot(.5f, .5f, .28f) }
            id == "quick" -> {
                st(.05f); c.drawRoundRect(x(.12f), x(.18f), x(.88f), x(.45f), x(.13f), x(.13f), p); c.drawRoundRect(x(.12f), x(.55f), x(.88f), x(.82f), x(.13f), x(.13f), p)
                dot(.74f, .315f, .09f); dot(.26f, .685f, .09f)
            }
            id == "gestures" -> { ring(.5f, .5f, .40f); dot(.5f, .5f, .06f) }
            id == "longpress" -> { dot(.5f, .5f, .12f); ring(.5f, .5f, .26f); ring(.5f, .5f, .40f) }
            id == "doubletap" -> {
                dot(.5f, .5f, .12f); ring(.5f, .5f, .26f)
                st(.06f); c.drawArc(x(.06f), x(.06f), x(.94f), x(.94f), 140f, 80f, false, p); c.drawArc(x(.06f), x(.06f), x(.94f), x(.94f), -40f, 80f, false, p)
            }
            id == "pinch" -> { line(.30f, .70f, .70f, .30f); dot(.70f, .30f, .12f); ring(.28f, .72f, .12f) }
            id == "holddrag" -> { line(.32f, .68f, .70f, .30f); ring(.28f, .72f, .12f); dot(.28f, .72f, .04f); dot(.74f, .26f, .08f) }
            id == "newgesture" -> {
                p.alpha = 150; st(.05f); p.pathEffect = DashPathEffect(floatArrayOf(x(.08f), x(.08f)), 0f)
                c.drawRoundRect(x(.12f), x(.12f), x(.88f), x(.88f), x(.14f), x(.14f), p); p.pathEffect = null
                p.alpha = 255; line(.5f, .32f, .5f, .68f, .07f); line(.32f, .5f, .68f, .5f, .07f)
            }
            id == "__back" -> { line(.82f, .5f, .18f, .5f, .07f); line(.18f, .5f, .42f, .28f, .07f); line(.18f, .5f, .42f, .72f, .07f) }
            else -> {
                fl(); p.textSize = w * .62f; p.textAlign = Paint.Align.CENTER
                c.drawText((ACTIONS[id] ?: "•").substringBefore(" "), w / 2, w * .72f, p)
            }
        }
    }
}

/** أصابع افتراضية / قرص وتدوير / ضغط مطوّل / نقر مزدوج / إمساك وسحب — مثل Custom و Gestures في iOS */
class FingersView(private val svc: AssistiveService, private val mode: String, private val n: Int, private val onClose: () -> Unit) : View(svc) {
    private val dm = resources.displayMetrics
    private val d = dm.density
    private val W = dm.widthPixels - 1f
    private val H = dm.heightPixels - 1f
    private val slop = 8f * d
    private val dots = Array(n) { k ->
        if (mode == "pinch") floatArrayOf(dm.widthPixels / 2f + (k * 2 - 1) * 60f * d, dm.heightPixels / 2f)
        else floatArrayOf(dm.widthPixels / 2f + (k - (n - 1) / 2f) * 90f * d, dm.heightPixels / 2f)
    }
    private val oneShot = mode == "double" || mode == "long" || mode == "holddrag"
    private var placed = false
    private var down = false
    private var tx = 0f; private var ty = 0f; private var cx = 0f; private var cy = 0f; private var t0 = 0L
    private val pts = ArrayList<FloatArray>()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x99FFFFFF.toInt() }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF8E8E93.toInt(); style = Paint.Style.STROKE; strokeWidth = 4f * d }
    private val hint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCCFFFFFF.toInt(); textSize = 16f * d; textAlign = Paint.Align.CENTER }
    private val idle = Runnable { onClose() }

    private fun sign(k: Int) = if (mode == "pinch" && placed && k == 1) -1f else 1f
    private fun live(k: Int): FloatArray {
        val dx = if (down) cx - tx else 0f; val dy = if (down) cy - ty else 0f; val s = sign(k)
        return floatArrayOf(dots[k][0] + s * dx, dots[k][1] + s * dy)
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); postDelayed(idle, 6000) }
    override fun onDetachedFromWindow() { removeCallbacks(idle); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        if (oneShot) {
            if (down) { c.drawCircle(cx, cy, 24f * d, fill); c.drawCircle(cx, cy, 24f * d, ring) }
            else c.drawText("المس المكان المطلوب", width / 2f, height / 2f, hint)
            return
        }
        for (k in 0 until n) { val l = live(k); c.drawCircle(l[0], l[1], 24f * d, fill); c.drawCircle(l[0], l[1], 24f * d, ring) }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        removeCallbacks(idle)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { down = true; tx = e.rawX; ty = e.rawY; cx = tx; cy = ty; t0 = e.eventTime; pts.clear(); pts.add(floatArrayOf(0f, 0f, 0f)) }
            MotionEvent.ACTION_MOVE -> { cx = e.rawX; cy = e.rawY; pts.add(floatArrayOf(cx - tx, cy - ty, (e.eventTime - t0).toFloat())) }
            MotionEvent.ACTION_UP -> { cx = e.rawX; cy = e.rawY; pts.add(floatArrayOf(cx - tx, cy - ty, (e.eventTime - t0).toFloat())); finish() }
            MotionEvent.ACTION_CANCEL -> { down = false; postDelayed(idle, 5000) }
        }
        invalidate(); return true
    }

    private fun fire(g: GestureDescription, after: () -> Unit) {
        setTouchable(svc.wm, false)
        val ok = try {
            svc.dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(x: GestureDescription?) { setTouchable(svc.wm, true); invalidate(); after() }
                override fun onCancelled(x: GestureDescription?) { setTouchable(svc.wm, true); invalidate(); after() }
            }, null)
        } catch (_: Exception) { false }
        if (!ok) { setTouchable(svc.wm, true); after() }
    }

    private fun finish() {
        val x0 = tx.coerceIn(0f, W); val y0 = ty.coerceIn(0f, H)
        val dur = max(50L, pts.last()[2].toLong())
        when (mode) {
            "fingers", "pinch" -> {
                if (mode == "pinch" && !placed) {   // أول سحبة: تحريك الدوائر لمكانها
                    for (k in 0 until n) { val l = live(k); dots[k][0] = l[0].coerceIn(0f, W); dots[k][1] = l[1].coerceIn(0f, H) }
                    down = false; placed = true; postDelayed(idle, 6000); return
                }
                val moved = pts.any { abs(it[0]) > slop || abs(it[1]) > slop }
                val g = GestureDescription.Builder()
                for (k in 0 until n) {
                    val s = sign(k); val sx = dots[k][0].coerceIn(0f, W); val sy = dots[k][1].coerceIn(0f, H)
                    val p = Path(); p.moveTo(sx, sy)
                    if (moved) pts.drop(1).forEach { p.lineTo((sx + s * it[0]).coerceIn(0f, W), (sy + s * it[1]).coerceIn(0f, H)) }
                    g.addStroke(GestureDescription.StrokeDescription(p, 0, dur))
                }
                for (k in 0 until n) { val l = live(k); dots[k][0] = l[0].coerceIn(0f, W); dots[k][1] = l[1].coerceIn(0f, H) }
                down = false
                fire(g.build()) { postDelayed(idle, 5000) }
            }
            "double" -> {
                down = false
                val p = Path(); p.moveTo(x0, y0)
                fire(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 40)).addStroke(GestureDescription.StrokeDescription(p, 120, 40)).build()) { onClose() }
            }
            "long" -> {
                down = false
                val p = Path(); p.moveTo(x0, y0)
                fire(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 1000)).build()) { onClose() }
            }
            "holddrag" -> {
                down = false
                val p0 = Path(); p0.moveTo(x0, y0)
                val s1 = GestureDescription.StrokeDescription(p0, 0, 500, true)
                fire(GestureDescription.Builder().addStroke(s1).build()) {
                    try {
                        val p = Path(); p.moveTo(x0, y0)
                        pts.drop(1).forEach { p.lineTo((x0 + it[0]).coerceIn(0f, W), (y0 + it[1]).coerceIn(0f, H)) }
                        val s2 = s1.continueStroke(p, 0, dur, false)
                        fire(GestureDescription.Builder().addStroke(s2).build()) { onClose() }
                    } catch (_: Exception) { onClose() }
                }
            }
        }
    }
}

/** دوائر الإيماءة المخصصة: اسحبها لمكان الاستخدام ثم اترك الإصبع فتتنفذ هناك (زي iOS تمامًا). تفضل ظاهرة لحد ما تضغط زرار القائمة. */
class GestureDotsView(private val svc: AssistiveService, private val name: String, private val starts: List<FloatArray>) : View(svc) {
    private val d = resources.displayMetrics.density
    private var ox = 0f; private var oy = 0f
    private var down = false; private var tx = 0f; private var ty = 0f; private var cx = 0f; private var cy = 0f
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xAA0A84FF.toInt() }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 3f * d }

    override fun onDraw(c: Canvas) {
        val dx = ox + if (down) cx - tx else 0f; val dy = oy + if (down) cy - ty else 0f
        starts.forEach { c.drawCircle(it[0] + dx, it[1] + dy, 26f * d, fill); c.drawCircle(it[0] + dx, it[1] + dy, 26f * d, ring) }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { down = true; tx = e.rawX; ty = e.rawY; cx = tx; cy = ty }
            MotionEvent.ACTION_MOVE -> { cx = e.rawX; cy = e.rawY }
            MotionEvent.ACTION_UP -> {
                ox += e.rawX - tx; oy += e.rawY - ty; down = false
                setTouchable(svc.wm, false)
                svc.playGesture(name, ox, oy) { setTouchable(svc.wm, true); invalidate() }
            }
            MotionEvent.ACTION_CANCEL -> down = false
        }
        invalidate(); return true
    }
}
