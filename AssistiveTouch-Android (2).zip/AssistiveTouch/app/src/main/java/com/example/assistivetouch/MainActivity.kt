package com.example.assistivetouch

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(dp(20), dp(24), dp(20), dp(24)) }
        setContentView(ScrollView(this).apply { addView(root) })
    }
    override fun onResume() { super.onResume(); build() }

    private fun label(t: String, size: Float = 14f) = TextView(this).apply { text = t; textSize = size; setPadding(0, dp(14), 0, dp(4)) }.also { root.addView(it) }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }.also { root.addView(it) }

    private fun build() {
        root.removeAllViews()
        val sp = Prefs.sp(this)
        label("AssistiveTouch", 26f)
        val on = (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "").contains(packageName)
        label(if (on) "✅ الخدمة تعمل" else "⚠️ فعّل الخدمة من إمكانية الوصول ثم ابحث عن AssistiveTouch")
        btn("تفعيل خدمة إمكانية الوصول") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("السماح بتعديل إعدادات النظام (السطوع / التدوير)") {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        }
        root.addView(Switch(this).apply {
            text = "إظهار الزر العائم"; isChecked = sp.getBoolean("btn", true)
            setOnCheckedChangeListener { _, c -> sp.edit().putBoolean("btn", c).apply() }
        })
        seek("حجم الزر", "size", 40, 90, 56)
        seek("الشفافية عند الخمول %", "opacity", 15, 100, 40)
        seek("مهلة اللمستين (مللي ثانية)", "dt", 150, 1000, 500)
        seek("مدة الضغطة المطوّلة (مللي ثانية)", "lp", 150, 1500, 350)

        label("الإجراءات المخصصة للزر", 18f)
        spinner("لمسة واحدة", "act_single")
        spinner("لمستان (Double Tap)", "act_double")
        spinner("ضغطة مطوّلة (Long Press)", "act_long")

        label("تخصيص القائمة الرئيسية", 18f)
        slotsEditor()

        label("الإيماءات المخصصة", 18f)
        btn("➕ إنشاء إيماءة جديدة") { startActivity(Intent(this, RecorderActivity::class.java)) }
        btn("🗑 إدارة الإيماءات") { manageGestures() }
        label("💡 للتشغيل السريع: أضف بلاطة AssistiveTouch من لوحة الإعدادات السريعة.")
    }

    private fun seek(title: String, key: String, min: Int, max: Int, def: Int) {
        label(title)
        root.addView(SeekBar(this).apply {
            this.max = max - min; progress = Prefs.sp(this@MainActivity).getInt(key, def) - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {}
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { Prefs.sp(this@MainActivity).edit().putInt(key, (s?.progress ?: 0) + min).apply() }
            })
        })
    }

    private fun spinner(title: String, key: String) {
        label(title)
        val ids = ArrayList<String>(); val names = ArrayList<String>()
        ACTIONS.forEach { ids += it.key; names += it.value }
        Prefs.gestures(this).keys().forEach { ids += "gesture:$it"; names += "✋ إيماءة: $it" }
        root.addView(Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, names)
            setSelection(ids.indexOf(Prefs.act(this@MainActivity, key)).coerceAtLeast(0))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    Prefs.sp(this@MainActivity).edit().putString(key, ids[pos]).apply()
                }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        })
    }

    private fun manageGestures() {
        val names = Prefs.gestures(this).keys().asSequence().toList()
        if (names.isEmpty()) { Toast.makeText(this, "لا توجد إيماءات", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle("اضغط على إيماءة لحذفها").setItems(names.toTypedArray()) { _, i ->
            Prefs.deleteGesture(this, names[i]); build()
        }.show()
    }

    private fun slotsEditor() {
        val slots = Prefs.slots(this).toMutableList()
        val ids = ACTIONS.keys.filter { it != "none" && it != "menu" } + Prefs.gestures(this).keys().asSequence().map { "gesture:$it" }.toList()
        val row = LinearLayout(this).apply { gravity = android.view.Gravity.CENTER_VERTICAL }
        row.addView(TextView(this).apply { text = "عدد الأيقونات: ${slots.size}  "; textSize = 14f })
        row.addView(Button(this).apply { text = "−"; setOnClickListener { if (slots.size > 1) { slots.removeAt(slots.size - 1); Prefs.setSlots(this@MainActivity, slots); build() } } })
        row.addView(Button(this).apply { text = "+"; setOnClickListener { if (slots.size < 8) { slots.add("home"); Prefs.setSlots(this@MainActivity, slots); build() } } })
        root.addView(row)
        slots.forEachIndexed { i, cur ->
            root.addView(Spinner(this).apply {
                adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, ids.map { lbl(it) })
                setSelection(ids.indexOf(cur).coerceAtLeast(0))
                onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { slots[i] = ids[pos]; Prefs.setSlots(this@MainActivity, slots) }
                    override fun onNothingSelected(p: AdapterView<*>?) {}
                }
            })
        }
        btn("↺ إعادة الضبط (القائمة الافتراضية)") { Prefs.sp(this).edit().remove("slots").apply(); build() }
    }
}
